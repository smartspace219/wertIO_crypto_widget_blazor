﻿// Assuming you've installed the required package using npm or yarn:
// npm install @wert-io/widget-initializer

//const WertWidget = require('').default; // Import the default export
//import WertWidget from "./lib/wert-io/widget-initializer"
////const WertWidget = require('./lib/wert-io/widget-initializer').default; // Import the default export
//const uuidv4 = require('uuid').v4; // Import the v4 function from uuid

//const options = {
//    partner_id: '01HJ3VMM454XKA737WAEQQEJV9',
//    click_id: uuidv4(), // Unique ID of purchase in your system
//    origin: 'https://sandbox.wert.io', // Needed only in sandbox
//    currency: 'USD',
//    commodity: 'ETH',
//    network: 'sepolia',
//    commodities: JSON.stringify([
//        {
//            commodity: 'BTC',
//            network: 'testnet',
//        },
//        {
//            commodity: 'ETH',
//            network: 'sepolia',
//        },
//    ]),
//    listeners: {
//        loaded: () => console.log('loaded'),
//    },
//};

//const wertWidget = new WertWidget(options);

//wertWidget.open();
